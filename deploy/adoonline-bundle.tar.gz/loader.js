(function () {
  function start() {
    var style = document.createElement("link");
    style.rel = "stylesheet";
    style.href = "styles.css?v=7";
    document.head.appendChild(style);

    var script = document.createElement("script");
    script.src = "app.bundle.js?v=7";
    script.async = false;
    script.onerror = function () {
      var mount = document.getElementById("app-mount");
      if (mount) {
        mount.innerHTML =
          '<p style="color:#fff;padding:24px;font-family:Segoe UI,sans-serif">Erreur de chargement.</p>';
      }
    };
    document.body.appendChild(script);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
